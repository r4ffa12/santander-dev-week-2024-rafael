rootProject.name = "santander-dev-week-2024"
